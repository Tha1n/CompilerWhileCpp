package whileComp.tests;

import com.google.inject.Inject;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.InMemoryFileSystemAccess;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.xtext.example.WhileCppInjectorProvider;
import org.xtext.example.generator.PrettyPrinterGenerator;
import org.xtext.example.whileCpp.Program;

@InjectWith(WhileCppInjectorProvider.class)
@RunWith(XtextRunner.class)
@SuppressWarnings("all")
public class SymbolTableTest {
  @Inject
  private ParseHelper<Program> parser;
  
  @Inject
  private PrettyPrinterGenerator genToTest;
  
  public String ConcatFName(final String FileName, final int NumFile) {
    String _string = Integer.valueOf(NumFile).toString();
    String _plus = (FileName + _string);
    return (_plus + ".wh");
  }
  
  @Test
  public void testIncorrect() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read incorrect%");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      final List<String> dico = this.genToTest.getFunctionsNames();
      boolean _isEmpty = dico.isEmpty();
      Assert.assertTrue(_isEmpty);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void correct1FunSomeVar() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      final List<String> dicoFun = this.genToTest.getFunctionsNames();
      final Set<String> dicoVar = this.genToTest.getVariables(0);
      boolean _contains = dicoFun.contains("p");
      Assert.assertTrue(_contains);
      boolean _contains_1 = dicoVar.contains("X");
      Assert.assertTrue(_contains_1);
      boolean _contains_2 = dicoVar.contains("Y");
      Assert.assertTrue(_contains_2);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void correct2FunSomeVar() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      _builder.newLine();
      _builder.newLine();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X, P");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      final List<String> dico = this.genToTest.getFunctionsNames();
      int _length = ((Object[])Conversions.unwrapArray(dico, Object.class)).length;
      boolean _equals = (_length == 2);
      Assert.assertTrue(_equals);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void incorrect2SameFun() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      _builder.newLine();
      _builder.newLine();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      final List<String> dico = this.genToTest.getFunctionsNames();
      boolean _isEmpty = dico.isEmpty();
      Assert.assertTrue(_isEmpty);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void correct1FunMultipleVar() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("if X then");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Z:=nil ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("if Z then");
      _builder.newLine();
      _builder.append("\t\t\t");
      _builder.append("M:=nil");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("fi");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("fi ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("if X then");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Z:=nil");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("fi");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      _builder.newLine();
      _builder.newLine();
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      final Set<String> dicoVar = this.genToTest.getVariables(0);
      boolean _contains = dicoVar.contains("X");
      Assert.assertTrue(_contains);
      boolean _contains_1 = dicoVar.contains("Y");
      Assert.assertTrue(_contains_1);
      boolean _contains_2 = dicoVar.contains("Z");
      Assert.assertTrue(_contains_2);
      boolean _contains_3 = dicoVar.contains("M");
      Assert.assertTrue(_contains_3);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
