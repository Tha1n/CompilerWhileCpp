package whileComp.tests;

import SymboleTable.CodeOp;
import SymboleTable.Fonction;
import SymboleTable.Label;
import SymboleTable.Quadruplet;
import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.InMemoryFileSystemAccess;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.xtext.example.WhileCppInjectorProvider;
import org.xtext.example.generator.ThreeAddGenerator;
import org.xtext.example.whileCpp.Program;

@InjectWith(WhileCppInjectorProvider.class)
@RunWith(XtextRunner.class)
@SuppressWarnings("all")
public class ThreeAddTest {
  @Inject
  private ParseHelper<Program> parser;
  
  @Inject
  private ThreeAddGenerator genToTest;
  
  @Test
  public void CorrectWithLabel() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:=nil ;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("while X do ");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("nop ;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("Y := X");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("od");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      List<Fonction> _functions = this.genToTest.getFunctions();
      Fonction _get = _functions.get(0);
      final ArrayList<Quadruplet> listQuad = _get.getM_quadList();
      boolean containsEqNil = false;
      boolean whileContainsNop = false;
      {
        int i = 0;
        int _size = listQuad.size();
        boolean _lessThan = (i < _size);
        boolean _while = _lessThan;
        while (_while) {
          {
            final Quadruplet quad = listQuad.get(i);
            CodeOp _op = quad.getOp();
            int _op_1 = _op.getOp();
            boolean _equals = (_op_1 == 2);
            if (_equals) {
              String _arg1 = quad.getArg1();
              boolean _equals_1 = Objects.equal(_arg1, "nil");
              if (_equals_1) {
                containsEqNil = true;
              }
            }
          }
          int _i = i;
          i = (_i + 1);
          int _size_1 = listQuad.size();
          boolean _lessThan_1 = (i < _size_1);
          _while = _lessThan_1;
        }
      }
      final ArrayList<Label> labels = this.genToTest.getLabelList();
      {
        int i = 0;
        int _size = labels.size();
        boolean _lessThan = (i < _size);
        boolean _while = _lessThan;
        while (_while) {
          {
            final Label label = labels.get(i);
            final ArrayList<Quadruplet> quadList = label.getCode();
            {
              int j = 0;
              int _size_1 = quadList.size();
              boolean _lessThan_1 = (j < _size_1);
              boolean _while_1 = _lessThan_1;
              while (_while_1) {
                {
                  final Quadruplet quadruplet = quadList.get(i);
                  CodeOp _op = quadruplet.getOp();
                  int _op_1 = _op.getOp();
                  boolean _equals = (_op_1 == 0);
                  if (_equals) {
                    whileContainsNop = true;
                  }
                }
                int _j = j;
                j = (_j + 1);
                int _size_2 = quadList.size();
                boolean _lessThan_2 = (j < _size_2);
                _while_1 = _lessThan_2;
              }
            }
          }
          int _i = i;
          i = (_i + 1);
          int _size_1 = labels.size();
          boolean _lessThan_1 = (i < _size_1);
          _while = _lessThan_1;
        }
      }
      Assert.assertTrue((containsEqNil && whileContainsNop));
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void correctHdTl() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("function p:");
      _builder.newLine();
      _builder.append("read X");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Y:= (hd (tl X))");
      _builder.newLine();
      _builder.append("%");
      _builder.newLine();
      _builder.append("write Y");
      final Program prog = this.parser.parse(_builder);
      final InMemoryFileSystemAccess fsaProg = new InMemoryFileSystemAccess();
      try {
        Resource _eResource = prog.eResource();
        this.genToTest.doGenerate(_eResource, fsaProg);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      List<Fonction> _functions = this.genToTest.getFunctions();
      Fonction _get = _functions.get(0);
      final ArrayList<Quadruplet> listQuad = _get.getM_quadList();
      boolean containsHD = false;
      boolean containsTL = false;
      {
        int i = 0;
        int _size = listQuad.size();
        boolean _lessThan = (i < _size);
        boolean _while = _lessThan;
        while (_while) {
          {
            final Quadruplet quad = listQuad.get(i);
            CodeOp _op = quad.getOp();
            int _op_1 = _op.getOp();
            boolean _equals = (_op_1 == 6);
            if (_equals) {
              containsHD = true;
            } else {
              CodeOp _op_2 = quad.getOp();
              int _op_3 = _op_2.getOp();
              boolean _equals_1 = (_op_3 == 7);
              if (_equals_1) {
                containsTL = true;
              }
            }
          }
          int _i = i;
          i = (_i + 1);
          int _size_1 = listQuad.size();
          boolean _lessThan_1 = (i < _size_1);
          _while = _lessThan_1;
        }
      }
      Assert.assertTrue((containsHD && containsTL));
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
