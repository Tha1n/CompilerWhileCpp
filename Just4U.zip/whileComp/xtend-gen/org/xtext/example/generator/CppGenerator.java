package org.xtext.example.generator;

import SymboleTable.CodeOp;
import SymboleTable.Fonction;
import SymboleTable.FunDictionary;
import SymboleTable.Label;
import SymboleTable.Logger;
import SymboleTable.Quadruplet;
import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class CppGenerator {
  private ArrayList<String> _previousFunctions = new ArrayList<String>();
  
  private ArrayList<String> _previousVar = new ArrayList<String>();
  
  private ArrayList<Label> m_labelList;
  
  public String generateCPP(final FunDictionary funcs, final HashMap<String, String> funNameTranslation, final ArrayList<Label> labelList, final ArrayList<String> errors) {
    String _xblockexpression = null;
    {
      int _size = errors.size();
      boolean _notEquals = (_size != 0);
      if (_notEquals) {
        {
          int i = 0;
          int _size_1 = errors.size();
          boolean _lessThan = (i < _size_1);
          boolean _while = _lessThan;
          while (_while) {
            String _get = errors.get(i);
            InputOutput.<String>println(_get);
            int _i = i;
            i = (_i + 1);
            int _size_2 = errors.size();
            boolean _lessThan_1 = (i < _size_2);
            _while = _lessThan_1;
          }
        }
        return "";
      }
      this.m_labelList = labelList;
      final List<Fonction> funcList = funcs.getFunctions();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("#include \"BinTree.h\"");
      _builder.newLine();
      _builder.append("#include <iostream>");
      _builder.newLine();
      _builder.append("#include <vector>");
      _builder.newLine();
      _builder.newLine();
      String cpp = _builder.toString();
      for (int i = 0; (i < funcList.size()); i++) {
        {
          Fonction _get = funcList.get(i);
          final String funName = _get.getM_name();
          final Fonction func = funcList.get(i);
          boolean _contains = this._previousFunctions.contains(funName);
          if (_contains) {
            StringConcatenation _builder_1 = new StringConcatenation();
            _builder_1.append("Error:");
            String _plus = (_builder_1.toString() + funName);
            StringConcatenation _builder_2 = new StringConcatenation();
            _builder_2.append(" ");
            _builder_2.append("previously declared!");
            _builder_2.newLine();
            String _plus_1 = (_plus + _builder_2);
            cpp = _plus_1;
          } else {
            this._previousFunctions.add(funName);
            StringConcatenation _builder_3 = new StringConcatenation();
            _builder_3.append("std::vector<BinTree> ");
            String _plus_2 = (cpp + _builder_3);
            String _get_1 = funNameTranslation.get(funName);
            String _plus_3 = (_plus_2 + _get_1);
            StringConcatenation _builder_4 = new StringConcatenation();
            _builder_4.append("(std::vector<BinTree> args)");
            _builder_4.newLine();
            _builder_4.append("{");
            _builder_4.newLine();
            _builder_4.append("\t");
            _builder_4.append("//Read");
            _builder_4.newLine();
            String _plus_4 = (_plus_3 + _builder_4);
            HashMap<String, String> _readVarList = func.getReadVarList();
            String _writeReadVar = this.writeReadVar(_readVarList);
            String _plus_5 = (_plus_4 + _writeReadVar);
            StringConcatenation _builder_5 = new StringConcatenation();
            _builder_5.append("//Instructions");
            _builder_5.newLine();
            String _plus_6 = (_plus_5 + _builder_5);
            ArrayList<Quadruplet> _m_quadList = func.getM_quadList();
            String _compileInstructions = this.compileInstructions(_m_quadList);
            String _plus_7 = (_plus_6 + _compileInstructions);
            StringConcatenation _builder_6 = new StringConcatenation();
            _builder_6.newLine();
            _builder_6.append("//write");
            _builder_6.newLine();
            String _plus_8 = (_plus_7 + _builder_6);
            ArrayList<String> _writeVarList = func.getWriteVarList();
            String _writeWriteVar = this.writeWriteVar(_writeVarList);
            String _plus_9 = (_plus_8 + _writeWriteVar);
            StringConcatenation _builder_7 = new StringConcatenation();
            _builder_7.append("}");
            _builder_7.newLine();
            _builder_7.newLine();
            String _plus_10 = (_plus_9 + _builder_7);
            cpp = _plus_10;
          }
        }
      }
      String _addMain = this.addMain(cpp, funcs, funNameTranslation);
      cpp = _addMain;
      Logger.PRINT(cpp);
      _xblockexpression = cpp;
    }
    return _xblockexpression;
  }
  
  public String writeReadVar(final HashMap<String, String> readVar) {
    String _xblockexpression = null;
    {
      String result = "";
      int cpt = 0;
      Set<Map.Entry<String, String>> _entrySet = readVar.entrySet();
      Iterator<Map.Entry<String, String>> iterator = _entrySet.iterator();
      while (iterator.hasNext()) {
        {
          final Map.Entry<String, String> pair = iterator.next();
          String _value = pair.getValue();
          this._previousVar.add(_value);
          String _value_1 = pair.getValue();
          String _plus = ((result + "BinTree ") + _value_1);
          String _plus_1 = (_plus + " = args.size() < ");
          String _plus_2 = (_plus_1 + Integer.valueOf(cpt));
          String _plus_3 = (_plus_2 + "? BinTree() : args.at(");
          String _plus_4 = (_plus_3 + Integer.valueOf(cpt));
          String _plus_5 = (_plus_4 + ");\n");
          result = _plus_5;
          int _cpt = cpt;
          cpt = (_cpt + 1);
        }
      }
      _xblockexpression = result;
    }
    return _xblockexpression;
  }
  
  public String writeWriteVar(final ArrayList<String> writeVar) {
    String _xblockexpression = null;
    {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("std::vector<BinTree> retour;");
      _builder.newLine();
      String result = _builder.toString();
      Iterator<String> iterator = writeVar.iterator();
      while (iterator.hasNext()) {
        {
          final String variable = iterator.next();
          boolean _contains = this._previousVar.contains(variable);
          boolean _not = (!_contains);
          if (_not) {
            this._previousVar.add(variable);
            String _result = result;
            result = (_result + (("BinTree " + variable) + ";\n"));
          }
          String _result_1 = result;
          result = (_result_1 + (("retour.push_back(" + variable) + ");\n"));
        }
      }
      String _result = result;
      result = (_result + "return retour;\n");
      _xblockexpression = result;
    }
    return _xblockexpression;
  }
  
  public String writeEntryArg(final HashMap<String, String> readVar) {
    String _xblockexpression = null;
    {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("std::vector<BinTree> entry;");
      _builder.newLine();
      String result = _builder.toString();
      {
        int i = 1;
        int _size = readVar.size();
        boolean _lessEqualsThan = (i <= _size);
        boolean _while = _lessEqualsThan;
        while (_while) {
          String _result = result;
          result = (_result + (((("argc > " + Integer.valueOf(i)) + "? entry.push_back(BinTree(argv[") + Integer.valueOf(i)) + "])) : entry.push_back(BinTree());\n"));
          int _i = i;
          i = (_i + 1);
          int _size_1 = readVar.size();
          boolean _lessEqualsThan_1 = (i <= _size_1);
          _while = _lessEqualsThan_1;
        }
      }
      _xblockexpression = result;
    }
    return _xblockexpression;
  }
  
  public String addMain(final String cpp, final FunDictionary funcs, final HashMap<String, String> funNameTranslation) {
    String _xblockexpression = null;
    {
      String result = cpp;
      List<Fonction> _functions = funcs.getFunctions();
      Fonction entryFunc = IterableExtensions.<Fonction>last(_functions);
      String _result = result;
      StringConcatenation _builder = new StringConcatenation();
      _builder.newLine();
      _builder.append("int main(int argc, char *argv[]) {");
      _builder.newLine();
      HashMap<String, String> _readVarList = entryFunc.getReadVarList();
      String _writeEntryArg = this.writeEntryArg(_readVarList);
      String _plus = (_builder.toString() + _writeEntryArg);
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.newLine();
      _builder_1.append("std::vector<BinTree> result = ");
      String _plus_1 = (_plus + _builder_1);
      String _m_name = entryFunc.getM_name();
      String _get = funNameTranslation.get(_m_name);
      String _plus_2 = (_plus_1 + _get);
      StringConcatenation _builder_2 = new StringConcatenation();
      _builder_2.append("(entry);");
      _builder_2.newLine();
      _builder_2.append("\t");
      _builder_2.append("for(auto bT : result)");
      _builder_2.newLine();
      _builder_2.append("\t\t");
      _builder_2.append("std::cout << bT << std::endl;");
      _builder_2.newLine();
      _builder_2.append("\t");
      _builder_2.append("return 0;");
      _builder_2.newLine();
      _builder_2.append("}");
      _builder_2.newLine();
      String _plus_3 = (_plus_2 + _builder_2);
      result = (_result + _plus_3);
      _xblockexpression = result;
    }
    return _xblockexpression;
  }
  
  public String compileInstructions(final ArrayList<Quadruplet> quadruplets) {
    String _xblockexpression = null;
    {
      String cpp = "";
      {
        int i = 0;
        int _size = quadruplets.size();
        boolean _lessThan = (i < _size);
        boolean _while = _lessThan;
        while (_while) {
          {
            final Quadruplet quadruplet = quadruplets.get(i);
            CodeOp _op = quadruplet.getOp();
            int _op_1 = _op.getOp();
            switch (_op_1) {
              case CodeOp.OP_NOP:
                String _cpp = cpp;
                StringConcatenation _builder = new StringConcatenation();
                _builder.append("//<NOP, _, _, _>");
                _builder.newLine();
                cpp = (_cpp + _builder);
                break;
              case CodeOp.OP_WHILE:
                String _cpp_1 = cpp;
                StringConcatenation _builder_1 = new StringConcatenation();
                _builder_1.append("//<WHILE ");
                CodeOp _op_2 = quadruplet.getOp();
                String _optLabel1 = _op_2.getOptLabel1();
                String _plus = (_builder_1.toString() + _optLabel1);
                StringConcatenation _builder_2 = new StringConcatenation();
                _builder_2.append(", ");
                String _plus_1 = (_plus + _builder_2);
                String _result = quadruplet.getResult();
                String _plus_2 = (_plus_1 + _result);
                StringConcatenation _builder_3 = new StringConcatenation();
                _builder_3.append(", ");
                String _plus_3 = (_plus_2 + _builder_3);
                String _arg1 = quadruplet.getArg1();
                String _string = _arg1.toString();
                String _plus_4 = (_plus_3 + _string);
                StringConcatenation _builder_4 = new StringConcatenation();
                _builder_4.append(",");
                String _plus_5 = (_plus_4 + _builder_4);
                String _arg2 = quadruplet.getArg2();
                String _string_1 = _arg2.toString();
                String _plus_6 = (_plus_5 + _string_1);
                StringConcatenation _builder_5 = new StringConcatenation();
                _builder_5.append(">");
                _builder_5.newLine();
                _builder_5.append("while (BinTree::isTrue(");
                String _plus_7 = (_plus_6 + _builder_5);
                String _arg1_1 = quadruplet.getArg1();
                String _plus_8 = (_plus_7 + _arg1_1);
                StringConcatenation _builder_6 = new StringConcatenation();
                _builder_6.append(")) {");
                _builder_6.newLine();
                String _plus_9 = (_plus_8 + _builder_6);
                CodeOp _op_3 = quadruplet.getOp();
                String _optLabel1_1 = _op_3.getOptLabel1();
                Label _label = this.getLabel(_optLabel1_1);
                ArrayList<Quadruplet> _code = _label.getCode();
                String _compileInstructions = this.compileInstructions(_code);
                String _plus_10 = (_plus_9 + _compileInstructions);
                StringConcatenation _builder_7 = new StringConcatenation();
                _builder_7.append("}");
                _builder_7.newLine();
                String _plus_11 = (_plus_10 + _builder_7);
                cpp = (_cpp_1 + _plus_11);
                break;
              case CodeOp.OP_IF:
                String _cpp_2 = cpp;
                StringConcatenation _builder_8 = new StringConcatenation();
                _builder_8.append("//<IF ");
                CodeOp _op_4 = quadruplet.getOp();
                String _optLabel1_2 = _op_4.getOptLabel1();
                String _plus_12 = (_builder_8.toString() + _optLabel1_2);
                StringConcatenation _builder_9 = new StringConcatenation();
                _builder_9.append(" ");
                String _plus_13 = (_plus_12 + _builder_9);
                CodeOp _op_5 = quadruplet.getOp();
                String _optLabel2 = _op_5.getOptLabel2();
                String _plus_14 = (_plus_13 + _optLabel2);
                StringConcatenation _builder_10 = new StringConcatenation();
                _builder_10.append(", ");
                String _plus_15 = (_plus_14 + _builder_10);
                String _result_1 = quadruplet.getResult();
                String _plus_16 = (_plus_15 + _result_1);
                StringConcatenation _builder_11 = new StringConcatenation();
                _builder_11.append(", ");
                String _plus_17 = (_plus_16 + _builder_11);
                String _arg1_2 = quadruplet.getArg1();
                String _string_2 = _arg1_2.toString();
                String _plus_18 = (_plus_17 + _string_2);
                StringConcatenation _builder_12 = new StringConcatenation();
                _builder_12.append(",");
                String _plus_19 = (_plus_18 + _builder_12);
                String _arg2_1 = quadruplet.getArg2();
                String _string_3 = _arg2_1.toString();
                String _plus_20 = (_plus_19 + _string_3);
                StringConcatenation _builder_13 = new StringConcatenation();
                _builder_13.append(">");
                _builder_13.newLine();
                _builder_13.append("if (BinTree::isTrue(");
                String _plus_21 = (_plus_20 + _builder_13);
                String _arg1_3 = quadruplet.getArg1();
                String _plus_22 = (_plus_21 + _arg1_3);
                StringConcatenation _builder_14 = new StringConcatenation();
                _builder_14.append(")) {");
                _builder_14.newLine();
                String _plus_23 = (_plus_22 + _builder_14);
                CodeOp _op_6 = quadruplet.getOp();
                String _optLabel1_3 = _op_6.getOptLabel1();
                Label _label_1 = this.getLabel(_optLabel1_3);
                ArrayList<Quadruplet> _code_1 = _label_1.getCode();
                String _compileInstructions_1 = this.compileInstructions(_code_1);
                String _plus_24 = (_plus_23 + _compileInstructions_1);
                StringConcatenation _builder_15 = new StringConcatenation();
                _builder_15.append("} else {");
                _builder_15.newLine();
                String _plus_25 = (_plus_24 + _builder_15);
                CodeOp _op_7 = quadruplet.getOp();
                String _optLabel2_1 = _op_7.getOptLabel2();
                Label _label_2 = this.getLabel(_optLabel2_1);
                ArrayList<Quadruplet> _code_2 = _label_2.getCode();
                String _compileInstructions_2 = this.compileInstructions(_code_2);
                String _plus_26 = (_plus_25 + _compileInstructions_2);
                StringConcatenation _builder_16 = new StringConcatenation();
                _builder_16.append("}");
                _builder_16.newLine();
                String _plus_27 = (_plus_26 + _builder_16);
                cpp = (_cpp_2 + _plus_27);
                break;
              case CodeOp.OP_FOREACH:
                String _cpp_3 = cpp;
                StringConcatenation _builder_17 = new StringConcatenation();
                _builder_17.append("//<FOREACH ");
                CodeOp _op_8 = quadruplet.getOp();
                String _optLabel1_4 = _op_8.getOptLabel1();
                String _plus_28 = (_builder_17.toString() + _optLabel1_4);
                StringConcatenation _builder_18 = new StringConcatenation();
                _builder_18.append(", ");
                String _plus_29 = (_plus_28 + _builder_18);
                String _result_2 = quadruplet.getResult();
                String _plus_30 = (_plus_29 + _result_2);
                StringConcatenation _builder_19 = new StringConcatenation();
                _builder_19.append(", ");
                String _plus_31 = (_plus_30 + _builder_19);
                String _arg1_4 = quadruplet.getArg1();
                String _string_4 = _arg1_4.toString();
                String _plus_32 = (_plus_31 + _string_4);
                StringConcatenation _builder_20 = new StringConcatenation();
                _builder_20.append(",");
                String _plus_33 = (_plus_32 + _builder_20);
                String _arg2_2 = quadruplet.getArg2();
                String _string_5 = _arg2_2.toString();
                String _plus_34 = (_plus_33 + _string_5);
                StringConcatenation _builder_21 = new StringConcatenation();
                _builder_21.append(">");
                _builder_21.newLine();
                _builder_21.append("for (auto const ");
                String _plus_35 = (_plus_34 + _builder_21);
                String _arg1_5 = quadruplet.getArg1();
                String _plus_36 = (_plus_35 + _arg1_5);
                StringConcatenation _builder_22 = new StringConcatenation();
                _builder_22.append(": ");
                String _plus_37 = (_plus_36 + _builder_22);
                String _arg2_3 = quadruplet.getArg2();
                String _plus_38 = (_plus_37 + _arg2_3);
                StringConcatenation _builder_23 = new StringConcatenation();
                _builder_23.append(") {");
                _builder_23.newLine();
                String _plus_39 = (_plus_38 + _builder_23);
                CodeOp _op_9 = quadruplet.getOp();
                String _optLabel1_5 = _op_9.getOptLabel1();
                Label _label_3 = this.getLabel(_optLabel1_5);
                ArrayList<Quadruplet> _code_3 = _label_3.getCode();
                String _compileInstructions_3 = this.compileInstructions(_code_3);
                String _plus_40 = (_plus_39 + _compileInstructions_3);
                StringConcatenation _builder_24 = new StringConcatenation();
                _builder_24.append("}");
                _builder_24.newLine();
                String _plus_41 = (_plus_40 + _builder_24);
                cpp = (_cpp_3 + _plus_41);
                break;
              case CodeOp.OP_AFF:
                String toAff = quadruplet.getResult();
                boolean _contains = this._previousVar.contains(toAff);
                boolean _equals = (_contains == false);
                if (_equals) {
                  this._previousVar.add(toAff);
                  toAff = ("BinTree " + toAff);
                }
                String result = quadruplet.getArg1();
                boolean _or = false;
                boolean _equals_1 = Objects.equal(result, "nil");
                if (_equals_1) {
                  _or = true;
                } else {
                  boolean _contains_1 = this._previousVar.contains(result);
                  boolean _equals_2 = (_contains_1 == false);
                  _or = _equals_2;
                }
                if (_or) {
                  boolean _equals_3 = Objects.equal(result, "nil");
                  if (_equals_3) {
                    String _result_3 = quadruplet.getResult();
                    result = _result_3;
                  }
                  this._previousVar.add(result);
                  result = ("BinTree " + result);
                  String _cpp_4 = cpp;
                  StringConcatenation _builder_25 = new StringConcatenation();
                  _builder_25.append("//<AFF, ");
                  String _result_4 = quadruplet.getResult();
                  String _plus_42 = (_builder_25.toString() + _result_4);
                  StringConcatenation _builder_26 = new StringConcatenation();
                  _builder_26.append(", ");
                  String _plus_43 = (_plus_42 + _builder_26);
                  String _arg1_6 = quadruplet.getArg1();
                  String _string_6 = _arg1_6.toString();
                  String _plus_44 = (_plus_43 + _string_6);
                  StringConcatenation _builder_27 = new StringConcatenation();
                  _builder_27.append(",");
                  String _plus_45 = (_plus_44 + _builder_27);
                  String _arg2_4 = quadruplet.getArg2();
                  String _string_7 = _arg2_4.toString();
                  String _plus_46 = (_plus_45 + _string_7);
                  StringConcatenation _builder_28 = new StringConcatenation();
                  _builder_28.append(">");
                  _builder_28.newLine();
                  String _plus_47 = (_plus_46 + _builder_28);
                  String _plus_48 = (_plus_47 + result);
                  StringConcatenation _builder_29 = new StringConcatenation();
                  _builder_29.append(";");
                  _builder_29.newLine();
                  _builder_29.newLine();
                  String _plus_49 = (_plus_48 + _builder_29);
                  cpp = (_cpp_4 + _plus_49);
                } else {
                  String _cpp_5 = cpp;
                  StringConcatenation _builder_30 = new StringConcatenation();
                  _builder_30.append("//<AFF, ");
                  String _result_5 = quadruplet.getResult();
                  String _plus_50 = (_builder_30.toString() + _result_5);
                  StringConcatenation _builder_31 = new StringConcatenation();
                  _builder_31.append(", ");
                  String _plus_51 = (_plus_50 + _builder_31);
                  String _arg1_7 = quadruplet.getArg1();
                  String _string_8 = _arg1_7.toString();
                  String _plus_52 = (_plus_51 + _string_8);
                  StringConcatenation _builder_32 = new StringConcatenation();
                  _builder_32.append(",");
                  String _plus_53 = (_plus_52 + _builder_32);
                  String _arg2_5 = quadruplet.getArg2();
                  String _string_9 = _arg2_5.toString();
                  String _plus_54 = (_plus_53 + _string_9);
                  StringConcatenation _builder_33 = new StringConcatenation();
                  _builder_33.append(">");
                  _builder_33.newLine();
                  String _plus_55 = (_plus_54 + _builder_33);
                  String _plus_56 = (_plus_55 + toAff);
                  StringConcatenation _builder_34 = new StringConcatenation();
                  _builder_34.append(" ");
                  _builder_34.append("= ");
                  String _plus_57 = (_plus_56 + _builder_34);
                  String _arg1_8 = quadruplet.getArg1();
                  String _plus_58 = (_plus_57 + _arg1_8);
                  StringConcatenation _builder_35 = new StringConcatenation();
                  _builder_35.append(";");
                  _builder_35.newLine();
                  _builder_35.newLine();
                  String _plus_59 = (_plus_58 + _builder_35);
                  cpp = (_cpp_5 + _plus_59);
                }
                break;
              case CodeOp.OP_CONS:
                String toAff_1 = quadruplet.getResult();
                boolean _contains_2 = this._previousVar.contains(toAff_1);
                boolean _equals_4 = (_contains_2 == false);
                if (_equals_4) {
                  this._previousVar.add(toAff_1);
                  toAff_1 = ("BinTree " + toAff_1);
                }
                String _cpp_6 = cpp;
                StringConcatenation _builder_36 = new StringConcatenation();
                _builder_36.append("//<CONS, ");
                String _result_6 = quadruplet.getResult();
                String _plus_60 = (_builder_36.toString() + _result_6);
                StringConcatenation _builder_37 = new StringConcatenation();
                _builder_37.append(", ");
                String _plus_61 = (_plus_60 + _builder_37);
                String _arg1_9 = quadruplet.getArg1();
                String _string_10 = _arg1_9.toString();
                String _plus_62 = (_plus_61 + _string_10);
                StringConcatenation _builder_38 = new StringConcatenation();
                _builder_38.append(",");
                String _plus_63 = (_plus_62 + _builder_38);
                String _arg2_6 = quadruplet.getArg2();
                String _string_11 = _arg2_6.toString();
                String _plus_64 = (_plus_63 + _string_11);
                StringConcatenation _builder_39 = new StringConcatenation();
                _builder_39.append(">");
                _builder_39.newLine();
                String _plus_65 = (_plus_64 + _builder_39);
                String _plus_66 = (_plus_65 + toAff_1);
                StringConcatenation _builder_40 = new StringConcatenation();
                _builder_40.append(" ");
                _builder_40.append("= BinTree::cons(");
                String _plus_67 = (_plus_66 + _builder_40);
                String _arg1_10 = quadruplet.getArg1();
                String _plus_68 = (_plus_67 + _arg1_10);
                StringConcatenation _builder_41 = new StringConcatenation();
                _builder_41.append(", ");
                String _plus_69 = (_plus_68 + _builder_41);
                String _arg2_7 = quadruplet.getArg2();
                String _plus_70 = (_plus_69 + _arg2_7);
                StringConcatenation _builder_42 = new StringConcatenation();
                _builder_42.append(");");
                _builder_42.newLine();
                String _plus_71 = (_plus_70 + _builder_42);
                cpp = (_cpp_6 + _plus_71);
                break;
              case CodeOp.OP_HD:
                String toAff_2 = quadruplet.getResult();
                boolean _contains_3 = this._previousVar.contains(toAff_2);
                boolean _equals_5 = (_contains_3 == false);
                if (_equals_5) {
                  this._previousVar.add(toAff_2);
                  toAff_2 = ("BinTree " + toAff_2);
                }
                String _cpp_7 = cpp;
                StringConcatenation _builder_43 = new StringConcatenation();
                _builder_43.append("//<HD, ");
                String _result_7 = quadruplet.getResult();
                String _plus_72 = (_builder_43.toString() + _result_7);
                StringConcatenation _builder_44 = new StringConcatenation();
                _builder_44.append(", ");
                String _plus_73 = (_plus_72 + _builder_44);
                String _arg1_11 = quadruplet.getArg1();
                String _string_12 = _arg1_11.toString();
                String _plus_74 = (_plus_73 + _string_12);
                StringConcatenation _builder_45 = new StringConcatenation();
                _builder_45.append(",");
                String _plus_75 = (_plus_74 + _builder_45);
                String _arg2_8 = quadruplet.getArg2();
                String _string_13 = _arg2_8.toString();
                String _plus_76 = (_plus_75 + _string_13);
                StringConcatenation _builder_46 = new StringConcatenation();
                _builder_46.append(">");
                _builder_46.newLine();
                String _plus_77 = (_plus_76 + _builder_46);
                String _plus_78 = (_plus_77 + toAff_2);
                StringConcatenation _builder_47 = new StringConcatenation();
                _builder_47.append(" ");
                _builder_47.append("= BinTree::hd(");
                String _plus_79 = (_plus_78 + _builder_47);
                String _arg1_12 = quadruplet.getArg1();
                String _plus_80 = (_plus_79 + _arg1_12);
                StringConcatenation _builder_48 = new StringConcatenation();
                _builder_48.append(");");
                _builder_48.newLine();
                String _plus_81 = (_plus_80 + _builder_48);
                cpp = (_cpp_7 + _plus_81);
                break;
              case CodeOp.OP_TL:
                String toAff_3 = quadruplet.getResult();
                boolean _contains_4 = this._previousVar.contains(toAff_3);
                boolean _equals_6 = (_contains_4 == false);
                if (_equals_6) {
                  this._previousVar.add(toAff_3);
                  toAff_3 = ("BinTree " + toAff_3);
                }
                String _cpp_8 = cpp;
                StringConcatenation _builder_49 = new StringConcatenation();
                _builder_49.append("//<TL, ");
                String _result_8 = quadruplet.getResult();
                String _plus_82 = (_builder_49.toString() + _result_8);
                StringConcatenation _builder_50 = new StringConcatenation();
                _builder_50.append(", ");
                String _plus_83 = (_plus_82 + _builder_50);
                String _arg1_13 = quadruplet.getArg1();
                String _string_14 = _arg1_13.toString();
                String _plus_84 = (_plus_83 + _string_14);
                StringConcatenation _builder_51 = new StringConcatenation();
                _builder_51.append(",");
                String _plus_85 = (_plus_84 + _builder_51);
                String _arg2_9 = quadruplet.getArg2();
                String _string_15 = _arg2_9.toString();
                String _plus_86 = (_plus_85 + _string_15);
                StringConcatenation _builder_52 = new StringConcatenation();
                _builder_52.append(">");
                _builder_52.newLine();
                String _plus_87 = (_plus_86 + _builder_52);
                String _plus_88 = (_plus_87 + toAff_3);
                StringConcatenation _builder_53 = new StringConcatenation();
                _builder_53.append(" ");
                _builder_53.append("= BinTree::tl(");
                String _plus_89 = (_plus_88 + _builder_53);
                String _arg1_14 = quadruplet.getArg1();
                String _plus_90 = (_plus_89 + _arg1_14);
                StringConcatenation _builder_54 = new StringConcatenation();
                _builder_54.append(");");
                _builder_54.newLine();
                String _plus_91 = (_plus_90 + _builder_54);
                cpp = (_cpp_8 + _plus_91);
                break;
              case CodeOp.OP_CALL:
                String toAff_4 = quadruplet.getResult();
                String[] variables = toAff_4.split(",");
                String _cpp_9 = cpp;
                StringConcatenation _builder_55 = new StringConcatenation();
                _builder_55.append("//<CALL, ");
                String _result_9 = quadruplet.getResult();
                String _plus_92 = (_builder_55.toString() + _result_9);
                StringConcatenation _builder_56 = new StringConcatenation();
                _builder_56.append(", ");
                String _plus_93 = (_plus_92 + _builder_56);
                String _arg1_15 = quadruplet.getArg1();
                String _string_16 = _arg1_15.toString();
                String _plus_94 = (_plus_93 + _string_16);
                StringConcatenation _builder_57 = new StringConcatenation();
                _builder_57.append(",");
                String _plus_95 = (_plus_94 + _builder_57);
                String _arg2_10 = quadruplet.getArg2();
                String _string_17 = _arg2_10.toString();
                String _plus_96 = (_plus_95 + _string_17);
                StringConcatenation _builder_58 = new StringConcatenation();
                _builder_58.append(">");
                _builder_58.newLine();
                String _plus_97 = (_plus_96 + _builder_58);
                cpp = (_cpp_9 + _plus_97);
                {
                  int v = 0;
                  final String[] _converted_variables = (String[])variables;
                  int _size_1 = ((List<String>)Conversions.doWrapArray(_converted_variables)).size();
                  boolean _lessThan_1 = (v < _size_1);
                  boolean _while_1 = _lessThan_1;
                  while (_while_1) {
                    {
                      final String variableToWrite = variables[v];
                      this._previousVar.add(variableToWrite);
                      String _cpp_10 = cpp;
                      String _arg1_16 = quadruplet.getArg1();
                      String _plus_98 = ((("BinTree " + variableToWrite) + " = ") + _arg1_16);
                      String _plus_99 = (_plus_98 + "(");
                      String _arg2_11 = quadruplet.getArg2();
                      String _plus_100 = (_plus_99 + _arg2_11);
                      String _plus_101 = (_plus_100 + ").at(");
                      String _plus_102 = (_plus_101 + Integer.valueOf(v));
                      String _plus_103 = (_plus_102 + ");\n");
                      cpp = (_cpp_10 + _plus_103);
                    }
                    int _v = v;
                    v = (_v + 1);
                    final String[] _converted_variables_1 = (String[])variables;
                    int _size_2 = ((List<String>)Conversions.doWrapArray(_converted_variables_1)).size();
                    boolean _lessThan_2 = (v < _size_2);
                    _while_1 = _lessThan_2;
                  }
                }
                break;
              default:
                break;
            }
          }
          int _i = i;
          i = (_i + 1);
          int _size_1 = quadruplets.size();
          boolean _lessThan_1 = (i < _size_1);
          _while = _lessThan_1;
        }
      }
      _xblockexpression = cpp;
    }
    return _xblockexpression;
  }
  
  public Label getLabel(final String name) {
    int i = 0;
    int _size = this.m_labelList.size();
    boolean _lessThan = (i < _size);
    boolean _while = _lessThan;
    while (_while) {
      Label _get = this.m_labelList.get(i);
      String _name = _get.getName();
      boolean _equals = Objects.equal(_name, name);
      if (_equals) {
        return this.m_labelList.get(i);
      }
      int _i = i;
      i = (_i + 1);
      int _size_1 = this.m_labelList.size();
      boolean _lessThan_1 = (i < _size_1);
      _while = _lessThan_1;
    }
    return null;
  }
}
