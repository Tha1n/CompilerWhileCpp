package SymboleTable;

import org.eclipse.xtext.xbase.lib.InputOutput;

@SuppressWarnings("all")
public class Logger {
  public static boolean _debug = false;
  
  public static void PRINT(final String toPrint) {
    if (Logger._debug) {
      InputOutput.<String>println(toPrint);
    }
  }
}
