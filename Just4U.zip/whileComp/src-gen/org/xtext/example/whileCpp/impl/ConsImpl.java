/**
 */
package org.xtext.example.whileCpp.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.xtext.example.whileCpp.Cons;
import org.xtext.example.whileCpp.Expr;
import org.xtext.example.whileCpp.WhileCppPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cons</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.example.whileCpp.impl.ConsImpl#getExprCons <em>Expr Cons</em>}</li>
 *   <li>{@link org.xtext.example.whileCpp.impl.ConsImpl#getExprConsAttList <em>Expr Cons Att List</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConsImpl extends MinimalEObjectImpl.Container implements Cons
{
  /**
   * The default value of the '{@link #getExprCons() <em>Expr Cons</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprCons()
   * @generated
   * @ordered
   */
  protected static final String EXPR_CONS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getExprCons() <em>Expr Cons</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprCons()
   * @generated
   * @ordered
   */
  protected String exprCons = EXPR_CONS_EDEFAULT;

  /**
   * The cached value of the '{@link #getExprConsAttList() <em>Expr Cons Att List</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprConsAttList()
   * @generated
   * @ordered
   */
  protected EList<Expr> exprConsAttList;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhileCppPackage.Literals.CONS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getExprCons()
  {
    return exprCons;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setExprCons(String newExprCons)
  {
    String oldExprCons = exprCons;
    exprCons = newExprCons;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, WhileCppPackage.CONS__EXPR_CONS, oldExprCons, exprCons));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Expr> getExprConsAttList()
  {
    if (exprConsAttList == null)
    {
      exprConsAttList = new EObjectContainmentEList<Expr>(Expr.class, this, WhileCppPackage.CONS__EXPR_CONS_ATT_LIST);
    }
    return exprConsAttList;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhileCppPackage.CONS__EXPR_CONS_ATT_LIST:
        return ((InternalEList<?>)getExprConsAttList()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhileCppPackage.CONS__EXPR_CONS:
        return getExprCons();
      case WhileCppPackage.CONS__EXPR_CONS_ATT_LIST:
        return getExprConsAttList();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhileCppPackage.CONS__EXPR_CONS:
        setExprCons((String)newValue);
        return;
      case WhileCppPackage.CONS__EXPR_CONS_ATT_LIST:
        getExprConsAttList().clear();
        getExprConsAttList().addAll((Collection<? extends Expr>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhileCppPackage.CONS__EXPR_CONS:
        setExprCons(EXPR_CONS_EDEFAULT);
        return;
      case WhileCppPackage.CONS__EXPR_CONS_ATT_LIST:
        getExprConsAttList().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhileCppPackage.CONS__EXPR_CONS:
        return EXPR_CONS_EDEFAULT == null ? exprCons != null : !EXPR_CONS_EDEFAULT.equals(exprCons);
      case WhileCppPackage.CONS__EXPR_CONS_ATT_LIST:
        return exprConsAttList != null && !exprConsAttList.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (exprCons: ");
    result.append(exprCons);
    result.append(')');
    return result.toString();
  }

} //ConsImpl
