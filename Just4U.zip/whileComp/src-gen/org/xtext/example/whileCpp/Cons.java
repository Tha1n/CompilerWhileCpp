/**
 */
package org.xtext.example.whileCpp;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cons</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.example.whileCpp.Cons#getExprCons <em>Expr Cons</em>}</li>
 *   <li>{@link org.xtext.example.whileCpp.Cons#getExprConsAttList <em>Expr Cons Att List</em>}</li>
 * </ul>
 *
 * @see org.xtext.example.whileCpp.WhileCppPackage#getCons()
 * @model
 * @generated
 */
public interface Cons extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Cons</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Cons</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Cons</em>' attribute.
   * @see #setExprCons(String)
   * @see org.xtext.example.whileCpp.WhileCppPackage#getCons_ExprCons()
   * @model
   * @generated
   */
  String getExprCons();

  /**
   * Sets the value of the '{@link org.xtext.example.whileCpp.Cons#getExprCons <em>Expr Cons</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Expr Cons</em>' attribute.
   * @see #getExprCons()
   * @generated
   */
  void setExprCons(String value);

  /**
   * Returns the value of the '<em><b>Expr Cons Att List</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.example.whileCpp.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Cons Att List</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Cons Att List</em>' containment reference list.
   * @see org.xtext.example.whileCpp.WhileCppPackage#getCons_ExprConsAttList()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExprConsAttList();

} // Cons
