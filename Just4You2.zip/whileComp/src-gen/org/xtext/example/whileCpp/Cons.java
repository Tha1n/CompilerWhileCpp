/**
 */
package org.xtext.example.whileCpp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cons</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.example.whileCpp.Cons#getExprCons <em>Expr Cons</em>}</li>
 *   <li>{@link org.xtext.example.whileCpp.Cons#getExprConsAtt1 <em>Expr Cons Att1</em>}</li>
 *   <li>{@link org.xtext.example.whileCpp.Cons#getExprConsAttList <em>Expr Cons Att List</em>}</li>
 * </ul>
 *
 * @see org.xtext.example.whileCpp.WhileCppPackage#getCons()
 * @model
 * @generated
 */
public interface Cons extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Cons</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Cons</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Cons</em>' attribute.
   * @see #setExprCons(String)
   * @see org.xtext.example.whileCpp.WhileCppPackage#getCons_ExprCons()
   * @model
   * @generated
   */
  String getExprCons();

  /**
   * Sets the value of the '{@link org.xtext.example.whileCpp.Cons#getExprCons <em>Expr Cons</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Expr Cons</em>' attribute.
   * @see #getExprCons()
   * @generated
   */
  void setExprCons(String value);

  /**
   * Returns the value of the '<em><b>Expr Cons Att1</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Cons Att1</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Cons Att1</em>' containment reference.
   * @see #setExprConsAtt1(Expr)
   * @see org.xtext.example.whileCpp.WhileCppPackage#getCons_ExprConsAtt1()
   * @model containment="true"
   * @generated
   */
  Expr getExprConsAtt1();

  /**
   * Sets the value of the '{@link org.xtext.example.whileCpp.Cons#getExprConsAtt1 <em>Expr Cons Att1</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Expr Cons Att1</em>' containment reference.
   * @see #getExprConsAtt1()
   * @generated
   */
  void setExprConsAtt1(Expr value);

  /**
   * Returns the value of the '<em><b>Expr Cons Att List</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Cons Att List</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Cons Att List</em>' containment reference.
   * @see #setExprConsAttList(ConsAttList)
   * @see org.xtext.example.whileCpp.WhileCppPackage#getCons_ExprConsAttList()
   * @model containment="true"
   * @generated
   */
  ConsAttList getExprConsAttList();

  /**
   * Sets the value of the '{@link org.xtext.example.whileCpp.Cons#getExprConsAttList <em>Expr Cons Att List</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Expr Cons Att List</em>' containment reference.
   * @see #getExprConsAttList()
   * @generated
   */
  void setExprConsAttList(ConsAttList value);

} // Cons
