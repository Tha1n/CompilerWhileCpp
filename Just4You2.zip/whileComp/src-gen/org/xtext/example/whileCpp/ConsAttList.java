/**
 */
package org.xtext.example.whileCpp;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cons Att List</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.example.whileCpp.ConsAttList#getConsList <em>Cons List</em>}</li>
 * </ul>
 *
 * @see org.xtext.example.whileCpp.WhileCppPackage#getConsAttList()
 * @model
 * @generated
 */
public interface ConsAttList extends EObject
{
  /**
   * Returns the value of the '<em><b>Cons List</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.example.whileCpp.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cons List</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cons List</em>' containment reference list.
   * @see org.xtext.example.whileCpp.WhileCppPackage#getConsAttList_ConsList()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getConsList();

} // ConsAttList
