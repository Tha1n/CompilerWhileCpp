package org.xtext.example;

public class UglyPrinterStandaloneSetup extends WhileCppStandaloneSetup {

}
